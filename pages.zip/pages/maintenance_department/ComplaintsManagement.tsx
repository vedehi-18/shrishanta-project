import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type Complaint = {
  id: number;
  hostel_name: string;
  room_no: string;
  title: string;
  category_name: string;
  status: string;
  created_at: string;
};

const MunicipalComplaints = () => {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [statuses, setStatuses] = useState<string[]>([]);

  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");
  const [hostel, setHostel] = useState("");
  const [date, setDate] = useState("");

  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  // ================= FETCH DATA =================
  const fetchComplaints = async () => {
    const query = new URLSearchParams({
      category,
      status,
      hostel,
      date,
    }).toString();

    const res = await fetch(
      `http://localhost:5000/complaints/municipal?${query}`
    );

    const data: Complaint[] = await res.json();
    setComplaints(data);

    // derive statuses from table
    const uniqueStatuses = [...new Set(data.map((c) => c.status))];
    setStatuses(uniqueStatuses);
  };

  const fetchCategories = async () => {
    const res = await fetch("http://localhost:5000/categories");
    const data = await res.json();
    setCategories(data);
  };

  useEffect(() => {
    fetchComplaints();
    fetchCategories();
  }, []);

  // ================= GROUP BY DATE → HOSTEL =================
  const groupComplaints = (data: Complaint[]) => {
    const grouped: any = {};

    data.forEach((c) => {
      const dateKey = new Date(c.created_at).toISOString().split("T")[0];

      if (!grouped[dateKey]) grouped[dateKey] = {};
      if (!grouped[dateKey][c.hostel_name])
        grouped[dateKey][c.hostel_name] = [];

      grouped[dateKey][c.hostel_name].push(c);
    });

    return grouped;
  };

  const groupedData = groupComplaints(complaints);

  // ================= STATUS UPDATE =================
  const updateStatus = async () => {
    if (!selectedComplaint) return;

    await fetch(
      `http://localhost:5000/complaints/${selectedComplaint.id}/status`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "in-progress" }),
      }
    );

    setSelectedComplaint(null);
    fetchComplaints();
  };

  return (
    <DashboardLayout title="Municipal Complaints">
      <div className="p-4 space-y-6">

        {/* 🔎 FILTERS */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Category */}
          <select
            className="border p-2 rounded"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.category_name}
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            className="border p-2 rounded"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="all">All Status</option>
            {statuses.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Date */}
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />

          {/* Hostel */}
          <Input
            placeholder="Hostel Name"
            value={hostel}
            onChange={(e) => setHostel(e.target.value)}
          />
        </div>

        <Button onClick={fetchComplaints}>Apply Filters</Button>

        {/* 📅 GROUPED VIEW */}
        {Object.keys(groupedData).length === 0 ? (
          <p>No complaints found</p>
        ) : (
          Object.entries(groupedData).map(([dateKey, hostels]: any) => (
            <div key={dateKey} className="border rounded p-4">

              {/* DATE HEADER */}
              <h2 className="text-xl font-bold mb-4">{dateKey}</h2>

              {Object.entries(hostels).map(([hostelName, list]: any) => (
                <div key={hostelName} className="mb-6">

                  {/* HOSTEL HEADER */}
                  <h3 className="text-lg font-semibold mb-2">
                    {hostelName}
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full border">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="border p-2">Room</th>
                          <th className="border p-2">Title</th>
                          <th className="border p-2">Category</th>
                          <th className="border p-2">Status</th>
                          <th className="border p-2">Time</th>
                        </tr>
                      </thead>

                      <tbody>
                        {list.map((c: Complaint) => (
                          <tr key={c.id}>
                            <td className="border p-2">{c.room_no}</td>
                            <td className="border p-2">{c.title}</td>
                            <td className="border p-2">{c.category_name}</td>

                            {/* STATUS BUTTON */}
                            <td className="border p-2">
                              <button
                                onClick={() => {
                                  if (c.status !== "pending") return;
                                  setSelectedComplaint(c);
                                }}
                                className={`px-3 py-1 rounded text-white ${
                                  c.status === "pending"
                                    ? "bg-yellow-500"
                                    : c.status === "in-progress"
                                    ? "bg-blue-500"
                                    : "bg-green-500"
                                }`}
                              >
                                {c.status}
                              </button>
                            </td>

                            <td className="border p-2">
                              {new Date(c.created_at).toLocaleTimeString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          ))
        )}

        {/* 🪟 POPUP */}
        {selectedComplaint && (
          <div className="fixed inset-0 flex items-center justify-center bg-black/40">
            <div className="bg-white p-6 rounded shadow-lg space-y-4">
              <p>
                Move complaint <b>{selectedComplaint.title}</b> to In-Progress?
              </p>

              <div className="flex gap-3">
                <Button onClick={updateStatus}>Confirm</Button>
                <Button
                  variant="outline"
                  onClick={() => setSelectedComplaint(null)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default MunicipalComplaints;