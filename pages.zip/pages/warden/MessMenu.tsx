import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";

interface FoodItem {
  id: number;
  food_name: string;
  category_id: number;
  category_name: string;
}

interface Category {
  category_id: number;
  category_name: string;
}

const WardenMessMenu = () => {
  const { user } = useAuth();

  const [foodsByCategory, setFoodsByCategory] = useState<any>({});
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedFoods, setSelectedFoods] = useState<number[]>([]);
  const [mealType, setMealType] = useState("Breakfast");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [menuData, setMenuData] = useState<any>({});
  const [hostelAssigned, setHostelAssigned] = useState(false);
  const [hostelName, setHostelName] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [newFoodName, setNewFoodName] = useState("");
  const [newFoodCategory, setNewFoodCategory] = useState<number | "">("");

  // ⭐ Copy/repeat menu
  const [copyFromDate, setCopyFromDate] = useState("");

  // ⭐ edit states
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [editCategory, setEditCategory] = useState<number | "">("");

  useEffect(() => {
    if (user?.email) {
      const email = user.email.trim();
      fetchFoods();
      fetchCategories();
      checkHostel(email);
      fetchMenu(email);
    }
  }, [user]);

  // ================= FETCH CATEGORIES =================
  const fetchCategories = async () => {
    const res = await fetch("http://localhost:5000/food-categories");
    const data = await res.json();
    setCategories(data || []);
  };

  // ================= FETCH FOODS =================
  const fetchFoods = async () => {
    const res = await fetch("http://localhost:5000/foods");
    const data = await res.json();

    const grouped: any = {};
    data.forEach((food: FoodItem) => {
      if (!grouped[food.category_name]) grouped[food.category_name] = [];
      grouped[food.category_name].push(food);
    });

    setFoodsByCategory(grouped);
  };

  // ================= CHECK HOSTEL =================
  const checkHostel = async (email: string) => {
    const res = await fetch(`http://localhost:5000/warden/hostel/${email}`);
    const data = await res.json();

    if (data?.hostel_name) {
      setHostelAssigned(true);
      setHostelName(data.hostel_name);
    } else setHostelAssigned(false);
  };

  // ================= ADD FOOD =================
  const addFood = async () => {
    if (!newFoodName.trim() || !newFoodCategory) {
      alert("Enter food and select category");
      return;
    }

    const res = await fetch("http://localhost:5000/food", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        food_name: newFoodName,
        category_id: newFoodCategory,
      }),
    });

    const data = await res.json();

    if (data.success) {
      alert("Food added ✅");
      setNewFoodName("");
      setNewFoodCategory("");
      fetchFoods();
    } else alert("Error adding food ❌");
  };

  // ================= EDIT FOOD =================
  const startEdit = (food: FoodItem) => {
    setEditingId(food.id);
    setEditName(food.food_name);
    setEditCategory(food.category_id);
  };

  const saveEdit = async () => {
    const res = await fetch(`http://localhost:5000/food/${editingId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        food_name: editName,
        category_id: editCategory,
      }),
    });

    const data = await res.json();

    if (data.success) {
      alert("Food updated ✅");
      setEditingId(null);
      fetchFoods();
    } else alert("Update failed ❌");
  };

  // ================= DELETE FOOD =================
  const deleteFood = async (id: number) => {
    if (!confirm("Delete this food?")) return;

    const res = await fetch(`http://localhost:5000/food/${id}`, {
      method: "DELETE",
    });

    const data = await res.json();

    if (data.success) {
      alert("Food deleted 🗑️");
      fetchFoods();
    } else alert("Delete failed ❌");
  };

  // ================= FETCH MENU =================
  const fetchMenu = async (email: string) => {
    const res = await fetch(`http://localhost:5000/mess-menu/${email}`);
    const data = await res.json();
    setMenuData(data || {});
  };

  // ⭐ NEW: Auto-fetch foods from another date when copyFromDate changes
  useEffect(() => {
    if (copyFromDate && user?.email) {
      const fetchCopiedMenu = async () => {
        try {
          const res = await fetch(
            `http://localhost:5000/mess-menu/${user.email.trim()}?date=${copyFromDate}&meal_type=${mealType}`
          );
          const data = await res.json();
          if (data?.meals && data.meals[mealType]) {
            // Flatten all category foods into selectedFoods array
            const foods: number[] = [];
            Object.values(data.meals[mealType]).forEach((foodList: any) => {
              foodList.forEach((f: any) => foods.push(f.id));
            });
            setSelectedFoods(foods);
          } else {
            setSelectedFoods([]); // No foods for that date
          }
        } catch (err) {
          console.error("Error fetching copied menu:", err);
          setSelectedFoods([]);
        }
      };
      fetchCopiedMenu();
    } else {
      setSelectedFoods([]);
    }
  }, [copyFromDate, mealType, user]);

  // ================= SAVE MENU =================
  const submitMenu = async () => {
    if (!copyFromDate && selectedFoods.length === 0) {
      alert("Select food or choose a date to copy from");
      return;
    }

    const payload: any = {
      email: user.email.trim(),
      menu_date: date,
      meal_type: mealType,
    };

    if (copyFromDate) payload.copy_from_date = copyFromDate;
    if (selectedFoods.length) payload.food_ids = selectedFoods;

    const res = await fetch("http://localhost:5000/mess-menu", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    if (data.success) {
      alert("Menu saved ✅");
      setSelectedFoods([]);
      setCopyFromDate("");
      fetchMenu(user.email.trim());
    } else {
      alert(`Error saving menu ❌: ${data.message || "Unknown error"}`);
    }
  };

  const toggleFoodSelection = (id: number) => {
    setSelectedFoods(prev =>
      prev.includes(id) ? prev.filter(fid => fid !== id) : [...prev, id]
    );
  };

  // ================= UI RETURN =================
  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold mb-2">Update Mess Menu</h1>

      {hostelAssigned && (
        <p className="text-sm text-gray-600 mb-4">
          Hostel: <b>{hostelName}</b>
        </p>
      )}

      {/* ⭐ ADD FOOD */}
      <div className="bg-gray-50 p-4 rounded mb-6 max-w-md">
        <h2 className="font-semibold mb-2">Add New Food</h2>

        <input
          type="text"
          placeholder="Food name"
          value={newFoodName}
          onChange={e => setNewFoodName(e.target.value)}
          className="border p-2 rounded w-full mb-2"
        />

        <select
          value={newFoodCategory}
          onChange={e => setNewFoodCategory(Number(e.target.value))}
          className="border p-2 rounded w-full mb-2"
        >
          <option value="">Select Category</option>
          {categories.map(cat => (
            <option key={cat.category_id} value={cat.category_id}>
              {cat.category_name}
            </option>
          ))}
        </select>

        <Button onClick={addFood}>Add Food</Button>
      </div>

      {/* ⭐ FOOD GRID */}
      <div className="flex gap-6">
        {/* Categories */}
        <div className="w-1/2">
          <h2 className="font-semibold mb-3">Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {Object.keys(foodsByCategory).map(category => (
              <div
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`p-3 rounded border cursor-pointer text-center 
                  break-words whitespace-normal leading-tight min-h-[70px] flex items-center justify-center
                  ${selectedCategory === category
                    ? "bg-blue-100 border-blue-400"
                    : "bg-white hover:bg-gray-50"
                  }`}
              >
                {category}
              </div>
            ))}
          </div>
        </div>

        {/* Foods */}
        <div className="w-1/2">
          <h2 className="font-semibold mb-3">{selectedCategory || "Select Category"}</h2>
          {selectedCategory &&
            foodsByCategory[selectedCategory]?.map((food: FoodItem) => (
              <div key={food.id} className="flex items-center gap-2 mb-2 border p-2 rounded">
                {editingId === food.id ? (
                  <>
                    <input
                      value={editName}
                      onChange={e => setEditName(e.target.value)}
                      className="border p-1 rounded"
                    />
                    <select
                      value={editCategory}
                      onChange={e => setEditCategory(Number(e.target.value))}
                      className="border p-1 rounded"
                    >
                      {categories.map(cat => (
                        <option key={cat.category_id} value={cat.category_id}>
                          {cat.category_name}
                        </option>
                      ))}
                    </select>
                    <Button onClick={saveEdit}>Save</Button>
                    <Button onClick={() => setEditingId(null)}>Cancel</Button>
                  </>
                ) : (
                  <>
                    <input
                      type="checkbox"
                      checked={selectedFoods.includes(food.id)}
                      onChange={() => toggleFoodSelection(food.id)}
                    />
                    <span className="flex-1">{food.food_name}</span>
                    <Button onClick={() => startEdit(food)}>Edit</Button>
                    <Button onClick={() => deleteFood(food.id)}>Delete</Button>
                  </>
                )}
              </div>
            ))}
        </div>
      </div>

      {/* ⭐ MENU SAVE */}
      <div className="mt-6 space-y-4 max-w-lg">
        <input
          type="date"
          value={date}
          onChange={e => setDate(e.target.value)}
          className="border p-2 w-full rounded"
        />

        <select
          value={mealType}
          onChange={e => setMealType(e.target.value)}
          className="border p-2 w-full rounded"
        >
          <option>Breakfast</option>
          <option>Lunch</option>
          <option>Snacks</option>
          <option>Dinner</option>
        </select>

        {/* ⭐ Copy menu from another date */}
        <div className="flex items-center gap-2 mt-2">
          <input
            type="checkbox"
            checked={!!copyFromDate}
            onChange={(e) => {
              if (!e.target.checked) setCopyFromDate("");
              else setCopyFromDate(date);
            }}
          />
          <span>select the date of which menu you want </span>

          {copyFromDate && (
            <input
              type="date"
              value={copyFromDate}
              onChange={(e) => setCopyFromDate(e.target.value)}
              className="border p-2 rounded"
            />
          )}
        </div>

        <Button onClick={submitMenu} disabled={!hostelAssigned}>
          Save Menu
        </Button>
      </div>

      {/* ⭐ SAVED MENU DISPLAY */}
      <div className="mt-10 max-w-4xl">
        <h2 className="text-xl font-semibold mb-4">Saved Menus</h2>
        {Object.keys(menuData).length === 0 ? (
          <p className="text-gray-500">No menu created yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2">Date</th>
                  <th className="border p-2">Meal</th>
                  <th className="border p-2">Category</th>
                  <th className="border p-2">Foods</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(menuData).map(([menuDate, menu]: any) =>
                  Object.entries(menu.meals).map(([mealType, categories]: any) => {
                    const categoryEntries = Object.entries(categories);
                    return categoryEntries.map(([category, foods]: any, idx) => (
                      <tr key={`${menuDate}-${mealType}-${category}`}>
                        {idx === 0 && (
                          <td rowSpan={categoryEntries.length} className="border p-2 text-center">
                            {new Date(menuDate).toLocaleDateString("en-GB")}
                          </td>
                        )}
                        {idx === 0 && (
                          <td rowSpan={categoryEntries.length} className="border p-2 text-center">
                            {mealType}
                          </td>
                        )}
                        <td className="border p-2">{category}</td>
                        <td className="border p-2">{foods.join(", ")}</td>
                      </tr>
                    ));
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default WardenMessMenu;