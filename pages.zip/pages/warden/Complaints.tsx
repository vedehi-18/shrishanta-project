import React, { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type Complaint = {
  id: number;
  hostelname: string;
  room_no: string;
  category_name: string; // ← correct property from backend
  title: string;
  description: string;
  status: "pending" | "in-progress" | "resolved";
  created_at: string;
  warden_note?: string;
};

const WardenComplaints = () => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all"); // ← new filter
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [wardenNote, setWardenNote] = useState("");

  // ================= LOAD COMPLAINTS =================
  const loadComplaints = async () => {
    if (!user?.email) return;

    try {
      // send query params to backend for filtering
      const url = new URL(`http://localhost:5000/complaints/warden/${user.email}`);
      if (categoryFilter !== "all") url.searchParams.append("category", categoryFilter);
      if (statusFilter !== "all") url.searchParams.append("status", statusFilter);

      const res = await fetch(url.toString());
      const data: Complaint[] = await res.json();
      setComplaints(data);
    } catch {
      toast.error("Failed to load complaints");
    }
  };

  // ================= LOAD CATEGORIES =================
  const loadCategories = async () => {
    try {
      const res = await fetch("http://localhost:5000/categories");
      const data = await res.json();
      setCategories(Array.isArray(data) ? data.map((c: any) => c.category_name) : []);
    } catch {
      setCategories([]);
    }
  };

  useEffect(() => {
    loadComplaints();
    loadCategories();
  }, [user, categoryFilter, statusFilter]); // refresh when filters change

  // ================= GROUP BY DATE & ROOM =================
  const groupedComplaints = complaints.reduce((acc: any, complaint) => {
    const date = new Date(complaint.created_at).toLocaleDateString();
    if (!acc[date]) acc[date] = {};
    if (!acc[date][complaint.room_no]) acc[date][complaint.room_no] = [];
    acc[date][complaint.room_no].push(complaint);
    return acc;
  }, {});

  // ================= RESOLVE COMPLAINT =================
  const resolveComplaint = async () => {
    if (!selectedComplaint) return;

    try {
      const res = await fetch(
        `http://localhost:5000/complaints/${selectedComplaint.id}/resolve`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ note: wardenNote }),
        }
      );

      const data = await res.json();

      if (data.success) {
        toast.success("Complaint resolved successfully");
        setSelectedComplaint(null);
        setWardenNote("");
        loadComplaints();
      } else {
        toast.error("Failed to resolve complaint");
      }
    } catch {
      toast.error("Server error");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <h1 className="text-3xl font-bold">Warden – Hostel Complaints</h1>

        {/* ================= FILTERS ================= */}
        <div className="flex gap-4 mb-4">
          <select
            className="border p-2 rounded"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="all">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <select
            className="border p-2 rounded"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In-Progress</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>

        {/* ================= NO COMPLAINTS ================= */}
        {Object.keys(groupedComplaints).length === 0 && (
          <p className="text-muted-foreground">
            No complaints found for this filter.
          </p>
        )}

        {/* ================= DISPLAY GROUPED ================= */}
        {Object.keys(groupedComplaints).map((date) => (
          <div key={date} className="space-y-4">
            <h2 className="text-xl font-semibold border-b pb-2">📅 {date}</h2>

            {Object.keys(groupedComplaints[date]).map((room) => (
              <div key={room} className="mb-4">
                <h3 className="font-semibold mb-2">Room: {room}</h3>

                {groupedComplaints[date][room].map((c: Complaint) => (
                  <div
                    key={c.id}
                    className="p-4 border rounded-xl cursor-pointer hover:bg-muted/30 transition"
                    onClick={() => {
                      setSelectedComplaint(c);
                      setWardenNote(c.warden_note || "");
                    }}
                  >
                    <div className="flex justify-between">
                      <div>
                        <p className="font-semibold">{c.title}</p>
                        <p className="text-sm text-muted-foreground">
                          Hostel <b>{c.hostelname}</b> • Category: <b>{c.category_name}</b>
                        </p>
                        <p className="text-sm">{c.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(c.created_at).toLocaleTimeString()}
                        </p>
                      </div>

                      <StatusBadge status={c.status} />
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        ))}

        {/* ================= DIALOG ================= */}
        <Dialog
          open={!!selectedComplaint}
          onOpenChange={() => setSelectedComplaint(null)}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Resolve Complaint</DialogTitle>
            </DialogHeader>

            {selectedComplaint && (
              <>
                <p className="font-semibold">{selectedComplaint.title}</p>

                <Textarea
                  placeholder="Add note for maintenance department..."
                  value={wardenNote}
                  onChange={(e) => setWardenNote(e.target.value)}
                />

                {selectedComplaint.status !== "resolved" && (
                  <Button className="mt-4" onClick={resolveComplaint}>
                    Mark as Resolved
                  </Button>
                )}
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
};

export default WardenComplaints;