import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";

interface Student {
  student_id: number;
  name: string;
}

const AssignRoom = () => {
  const { user } = useAuth();

  const [roomNo, setRoomNo] = useState("");
  const [capacity, setCapacity] = useState(1);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<number[]>([]);
  const [assignedStudents, setAssignedStudents] = useState<Student[]>([]);
  const [rooms, setRooms] = useState<any>({});

  // ✅ Fetch students only from warden hostel
  const fetchStudents = () => {
    fetch(`http://localhost:5000/students/warden/${user.email}`)
      .then(res => res.json())
      .then(data => setStudents(data));
  };

  // ✅ Fetch students already in this room
  const fetchAssignedStudents = () => {
    if (!roomNo) return;

    fetch(`http://localhost:5000/rooms/${roomNo}/students/${user.email}`)
      .then(res => res.json())
      .then(data => setAssignedStudents(data));
  };

  // ✅ Fetch room occupancy chart
  const fetchRooms = () => {
    fetch(`http://localhost:5000/warden/rooms/${user.email}`)
      .then(res => res.json())
      .then(data => setRooms(data));
  };

  useEffect(() => {
    fetchStudents();
    fetchRooms();
  }, []);

  useEffect(() => {
    fetchAssignedStudents();
  }, [roomNo]);

  // ✅ Assign students
  const handleSubmit = async (e: any) => {
    e.preventDefault();

    if (selectedStudents.length > capacity) {
      alert("Selected students exceed room capacity!");
      return;
    }

    const res = await fetch("http://localhost:5000/assign-room", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: user.email,
        room_no: roomNo,
        student_ids: selectedStudents,
        capacity
      })
    });

    const data = await res.json();

    if (data.success) {
      alert("Room updated successfully!");
      setSelectedStudents([]);
      fetchAssignedStudents();
      fetchRooms();
    } else {
      alert(data.message || "Failed to assign");
    }
  };

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold mb-4">Assign Students to Room</h1>

      {/* ================= ASSIGN FORM ================= */}
      <form onSubmit={handleSubmit} className="space-y-4 max-w-md">

        <Input
          placeholder="Room Number"
          value={roomNo}
          onChange={(e) => setRoomNo(e.target.value)}
          required
        />

        <Input
          type="number"
          placeholder="Room Capacity"
          value={capacity}
          onChange={(e) => setCapacity(Number(e.target.value))}
          required
        />

        <select
          multiple
          value={selectedStudents.map(String)}
          onChange={(e) => {
            const options = Array.from(e.target.selectedOptions).map(opt =>
              Number(opt.value)
            );
            setSelectedStudents(options);
          }}
          className="w-full border p-2 rounded"
        >
          {students.map(s => (
            <option key={s.student_id} value={s.student_id}>
              {s.name}
            </option>
          ))}
        </select>

        <Button type="submit">Assign Students</Button>
      </form>

      {/* ================= CURRENT ROOM STUDENTS ================= */}
      <div className="mt-6">
        <h2 className="font-bold text-lg">Students in this Room:</h2>

        {assignedStudents.length === 0 ? (
          <p className="text-gray-500">No students assigned</p>
        ) : (
          <ul className="list-disc pl-5">
            {assignedStudents.map(s => (
              <li key={s.student_id}>{s.name}</li>
            ))}
          </ul>
        )}
      </div>

      {/* ================= ROOM OCCUPANCY CHART ================= */}
      <div className="mt-10">
        <h2 className="text-xl font-bold mb-3">Room Occupancy Chart</h2>

        {Object.keys(rooms).length === 0 ? (
          <p className="text-gray-500">No rooms yet</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(rooms).map(([roomNo, students]: any) => (
              <div
                key={roomNo}
                className="border rounded-lg p-4 shadow bg-white"
              >
                <h3 className="font-semibold text-lg mb-2">
                  Room {roomNo}
                </h3>

                {students.length === 0 ? (
                  <p className="text-gray-400">Empty</p>
                ) : (
                  <ul className="list-disc pl-5">
                    {students.map((s: any) => (
                      <li key={s.student_id}>{s.name}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default AssignRoom;