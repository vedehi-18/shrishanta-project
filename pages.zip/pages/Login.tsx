// src/pages/Login.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Shield, Building2, Crown } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";

type Role = "student" | "warden" | "maintenance_department" | "admin";

const Login: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<Role>("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();
  const { setUser } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role: selectedRole }),
      });

      const data = await res.json();

      if (!data.success) {
        alert(data.message || "Login failed");
        setIsLoading(false);
        return;
      }

      const userInfo = {
        email: data.email,
        name: data.name,
        role: data.role,
        hostelname: data.hostelname || "",
      };

      setUser(userInfo);
      localStorage.setItem("hostelUser", JSON.stringify(userInfo));

      // ✅ ROLE-BASED NAVIGATION
      switch (data.role) {
        case "student":
          navigate("/dashboard");
          break;
        case "warden":
          navigate("/warden/dashboard");
          break;
        case "maintenance_department":
  navigate("/municipal/dashboard");
  break;
        case "admin":
  navigate("/admin/dashboard");
  break;

        default:
          alert("Unknown role!");
      }
    } catch (err) {
      console.error(err);
      alert("Server not responding");
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex font-grotesque bg-gradient-to-br from-[#0c0ab1] via-[#4709b3] to-[#8852e7]">
      {/* LEFT PANEL */}
      <div className="hidden lg:flex w-1/2 text-white">
        <div className="flex flex-col w-full px-16 py-12">
          <div className="flex items-center gap-3 mb-16">
            <img src="/bv logo cir.png" alt="Banasthali Vidyapith" className="w-12 h-12" />
            <div className="leading-tight">
              <p className="text-sm font-medium">वनस्थली विद्यापीठ</p>
              <p className="text-sm opacity-90">Banasthali Vidyapith</p>
            </div>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <div className="flex items-center gap-3 mb-4">
              <Building2 className="w-9 h-9 text-white" />
              <h1 className="text-5xl font-bold">ShriShanta</h1>
            </div>
            <h2 className="text-2xl font-semibold mb-8">
              Hostel Management System
            </h2>
            <p className="text-lg leading-relaxed opacity-90 max-w-xl">
              Simplify hostel living with ShriShanta – submit complaints, manage
              mess menus, and stay updated seamlessly.
            </p>
          </div>

          <div className="flex justify-center mt-12">
            <img src="/bv.png" alt="Hostel" className="rounded-2xl shadow-2xl max-w-lg w-full" />
          </div>
        </div>
      </div>

      {/* RIGHT PANEL */}
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="w-full max-w-md bg-white rounded-2xl p-8 shadow-xl">
          <h2 className="text-3xl font-bold text-center mb-6">Welcome </h2>

          {/* ROLE BUTTONS */}
        
<div className="grid grid-cols-2 gap-3 mb-6">
  {[
    { label: "Student", value: "student", icon: User },
    { label: "Warden", value: "warden", icon: Building2 },
    { label: "Maintenance Department", value: "maintenance_department", icon: Shield },
  ].map((r) => {
    const Icon = r.icon;
    return (
      <button
        key={r.value}
        onClick={() => setSelectedRole(r.value as Role)}
        className={cn(
          "border rounded-xl py-3 flex justify-center items-center gap-2",
          selectedRole === r.value
            ? "border-[#5B2DAD] bg-[#F1ECFA] text-[#5B2DAD]"
            : "border-gray-200 hover:bg-gray-50"
        )}
      >
        <Icon className="w-4 h-4" />
        {r.label}
      </button>
    );
  })}
</div>


          {/* LOGIN FORM */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <Label>Password</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 text-white"
              style={{ background: "linear-gradient(90deg,#201ec1,#8852e7)" }}
            >
              {isLoading ? "Checking..." : "Sign In"}
            </Button>
            {/* ADMIN LOGIN LINK */}
<div className="mt-6 text-center">
  <div className="flex items-center gap-2 mb-2">
    <div className="flex-1 h-px bg-gray-300" />
    <span className="text-xs text-gray-400">ADMIN ACCESS</span>
    <div className="flex-1 h-px bg-gray-300" />
  </div>

  <button
    type="button"
     onClick={() => navigate("/admin/login")}
    className="text-sm font-medium text-[#5B2DAD] hover:underline"
  >
    Login as Admin
  </button>
</div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
