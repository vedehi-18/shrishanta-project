import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";

type Hostel = {
  hostel_id: number;
  hostel_name: string;
};

type Warden = {
  warden_id: number;
  name: string;
};

const AdminAssignWarden: React.FC = () => {
  const [hostels, setHostels] = useState<Hostel[]>([]);
  const [wardens, setWardens] = useState<Warden[]>([]);
  const [selectedHostel, setSelectedHostel] = useState<number | "">("");
  const [selectedWardens, setSelectedWardens] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);

  // 🔹 Load hostels & wardens
  useEffect(() => {
    fetch("http://localhost:5000/admin/hostels")
      .then(res => res.json())
      .then(data => setHostels(data))
      .catch(err => console.error("Hostel error:", err));

    fetch("http://localhost:5000/admin/wardens")
      .then(res => res.json())
      .then(data => setWardens(data))
      .catch(err => console.error("Warden error:", err));
  }, []);

  // 🔹 Toggle warden checkbox
  const toggleWarden = (wardenId: number) => {
    setSelectedWardens(prev =>
      prev.includes(wardenId)
        ? prev.filter(id => id !== wardenId)
        : [...prev, wardenId]
    );
  };

  // 🔹 Submit assignment (NO HANG)
  const handleSubmit = async () => {
    if (!selectedHostel || selectedWardens.length === 0) {
      alert("Please select hostel and at least one warden");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch(
        "http://localhost:5000/admin/assign-warden-hostel",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            hostel_id: selectedHostel,
            warden_ids: selectedWardens,
          }),
        }
      );

      if (!res.ok) {
        throw new Error("Server error");
      }

      const data = await res.json();

      if (data.success) {
        alert("Wardens assigned successfully ✅");
        setSelectedWardens([]);
      } else {
        alert("Failed to assign wardens ❌");
      }
    } catch (error) {
      console.error("Assign error:", error);
      alert("Server error or backend not responding");
    } finally {
      // 🔥 prevents infinite loading
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8 mt-10">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">
          Assign Wardens to Hostel
        </h1>

        {/* 🔽 Hostel Dropdown */}
        <div className="mb-6">
          <label className="block font-semibold mb-2">Select Hostel</label>
          <select
            value={selectedHostel}
            onChange={e =>
              setSelectedHostel(
                e.target.value ? Number(e.target.value) : ""
              )
            }
            className="w-full border rounded-md p-2"
          >
            <option value="">-- Select Hostel --</option>
            {hostels.map(h => (
              <option key={h.hostel_id} value={h.hostel_id}>
                {h.hostel_name}
              </option>
            ))}
          </select>
        </div>

        {/* ☑️ Warden Checkbox List */}
        <div className="mb-6">
          <p className="font-semibold mb-3">Select Wardens</p>

          {wardens.length === 0 ? (
            <p className="text-gray-500">No wardens available</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {wardens.map(w => (
                <label
                  key={w.warden_id}
                  className="flex items-center gap-3 border rounded-lg p-3 cursor-pointer hover:bg-gray-50"
                >
                  <input
                    type="checkbox"
                    checked={selectedWardens.includes(w.warden_id)}
                    onChange={() => toggleWarden(w.warden_id)}
                  />
                  <span className="font-medium">{w.name}</span>
                </label>
              ))}
            </div>
          )}
        </div>

        {/* ✅ Submit Button */}
        <Button
          onClick={handleSubmit}
          disabled={loading}
          className="mt-4"
        >
          {loading ? "Assigning..." : "Assign Wardens"}
        </Button>
      </div>
    </DashboardLayout>
  );
};

export default AdminAssignWarden;
