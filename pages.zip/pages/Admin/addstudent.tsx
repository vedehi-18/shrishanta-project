import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Course {
  course_id: number;
  course_name: string;
  course_year: number;
}

interface Hostel {
  hostel_id: number;
  hostel_name: string;
}

const AssignHostel = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [hostels, setHostels] = useState<Hostel[]>([]);
  const [selectedCourse, setSelectedCourse] = useState("");
  const [selectedHostel, setSelectedHostel] = useState("");
  const [loading, setLoading] = useState(false);

  // Fetch courses and hostels
  useEffect(() => {
    fetch("http://localhost:5000/admin/courses")
      .then(res => res.json())
      .then(setCourses)
      .catch(err => console.log(err));

    fetch("http://localhost:5000/hostels")
      .then(res => res.json())
      .then(setHostels)
      .catch(err => console.log(err));
  }, []);

  const handleSubmit = async () => {
    if (!selectedCourse || !selectedHostel) {
      alert("Please select course and hostel");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("http://localhost:5000/admin/assign-hostel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          course_id: Number(selectedCourse),
          hostel_id: Number(selectedHostel),
        }),
      });

      const data = await res.json();
      setLoading(false);

      if (data.success) {
        alert(data.message);
        setSelectedCourse("");
        setSelectedHostel("");
      } else {
        alert(data.message || "Failed to assign hostel");
      }
    } catch (err) {
      console.log(err);
      setLoading(false);
      alert("Something went wrong!");
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-md space-y-6">
        <h1 className="text-2xl font-bold">Assign Hostel to Course</h1>

        {/* Course Dropdown */}
        <div>
          <Label>Course</Label>
          <Select value={selectedCourse} onValueChange={setSelectedCourse}>
            <SelectTrigger>
              <SelectValue placeholder="Select Course" />
            </SelectTrigger>
            <SelectContent>
              {courses.map(c => (
                <SelectItem key={c.course_id} value={String(c.course_id)}>
                  {c.course_name} ({c.course_year})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Hostel Dropdown */}
        <div>
          <Label>Hostel</Label>
          <Select value={selectedHostel} onValueChange={setSelectedHostel}>
            <SelectTrigger>
              <SelectValue placeholder="Select Hostel" />
            </SelectTrigger>
            <SelectContent>
              {hostels.map(h => (
                <SelectItem key={h.hostel_id} value={String(h.hostel_id)}>
                  {h.hostel_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button onClick={handleSubmit} disabled={loading}>
          {loading ? "Saving..." : "Assign Hostel"}
        </Button>
      </div>
    </DashboardLayout>
  );
};

export default AssignHostel;
