import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAuth } from '@/context/AuthContext';

const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState<any[]>([]);
  const [hostelName, setHostelName] = useState<string | null>(null);
  const [roomNo, setRoomNo] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.email) return;

    fetch(`http://localhost:5000/student-data?email=${user.email}`)
      .then(res => res.json())
      .then(data => {
        setHostelName(data.hostelname);
        setRoomNo(data.room_no);
        setComplaints(data.complaints || []);
      })
      .catch(() => {
        setHostelName(null);
        setRoomNo(null);
        setComplaints([]);
      });
  }, [user]);

  return (
    <DashboardLayout>
      <div
        className="bg-cover bg-center min-h-screen flex items-center justify-center p-10"
        style={{ backgroundImage: "url('/bv.png')" }}
      >
        <div className="bg-white/90 rounded-xl shadow-xl p-10 space-y-6 max-w-4xl w-full border border-indigo-300">

          <div>
            <h1 className="text-3xl font-bold text-gray-800">
              Welcome, {user?.name}
            </h1>

            <p className="text-gray-500 mt-2">
              {hostelName
                ? `Hostel: ${hostelName}`
                : 'Hostel not assigned yet'}
            </p>

            {roomNo && (
              <p className="text-gray-500">
                Room No: {roomNo}
              </p>
            )}
          </div>

          <div className="text-gray-600 max-w-xl">
            <p className="font-medium">Your hostel services, simplified!</p>
            <p className="mt-2">
              Check today’s mess menu or submit and track complaints with just a click.
            </p>
          </div>

          <p className="font-semibold text-gray-800">
            Note:{' '}
            <span className="font-normal">
              Hostel gates close at 9:00 PM sharp.
            </span>
          </p>

        </div>
      </div>
    </DashboardLayout>
  );
};

export default StudentDashboard;
