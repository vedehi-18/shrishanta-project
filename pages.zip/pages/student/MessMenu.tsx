import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Coffee, Sun, Cookie, Moon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

const MessMenu = () => {
  const { user } = useAuth();
  const [menuData, setMenuData] = useState({});

  useEffect(() => {
    if (!user?.email) return;

    fetch(`http://localhost:5000/mess-menu/student/${user.email}`)
      .then(res => res.json())
      .then(data => setMenuData(data || {}))
      .catch(() => setMenuData({}));
  }, [user]);

  // today in yyyy-mm-dd format
  const todayISO = new Date().toISOString().split("T")[0];

  // sort upcoming dates
  const sortedDates = Object.keys(menuData)
    .sort()
    .filter(date => date >= todayISO);

  // today's menu
  const todayMenu = menuData[todayISO];

  // helper: convert yyyy-mm-dd → DD-MM-YYYY
  const formatDate = dateStr => {
    const [year, month, day] = dateStr.split("-");
    return `${day}-${month}-${year}`;
  };

  // helper: get day name from date string
  const getDayName = dateStr => {
    const date = new Date(dateStr + "T00:00:00");
    return date.toLocaleDateString("en-GB", { weekday: "long" });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <h1 className="text-3xl font-bold">Mess Menu</h1>

        {/* ================= TODAY MENU ================= */}
        {todayMenu && Object.keys(todayMenu.meals).length > 0 ? (
          <div className="bg-card p-6 rounded-xl border shadow">
            <h2 className="text-xl font-bold mb-4">
              🍽 Today — {formatDate(todayISO)} ({getDayName(todayISO)})
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MealCard title="Breakfast" value={todayMenu.meals.breakfast} icon={<Coffee />} />
              <MealCard title="Lunch" value={todayMenu.meals.lunch} icon={<Sun />} />
              <MealCard title="Snacks" value={todayMenu.meals.snacks} icon={<Cookie />} />
              <MealCard title="Dinner" value={todayMenu.meals.dinner} icon={<Moon />} />
            </div>
          </div>
        ) : (
          <p className="text-gray-500">Today menu not available</p>
        )}

        {/* ================= UPCOMING MENU ================= */}
        {sortedDates.length > 0 ? (
          <div className="bg-card rounded-xl border overflow-hidden">
            <h2 className="text-lg font-semibold p-4 border-b">📅 Upcoming Menu</h2>

            <table className="w-full">
              <thead className="bg-secondary">
                <tr>
                  <th className="p-4 text-left">Date</th>
                  <th className="p-4">Breakfast</th>
                  <th className="p-4">Lunch</th>
                  <th className="p-4">Snacks</th>
                  <th className="p-4">Dinner</th>
                </tr>
              </thead>

              <tbody>
                {sortedDates.map(date => {
                  const dayMenu = menuData[date];
                  return (
                    <tr
                      key={date}
                      className={`border-t ${date === todayISO ? "bg-muted font-medium" : ""}`}
                    >
                      <td className="p-4">
                        {formatDate(date)} ({getDayName(date)})
                      </td>
                      <td className="p-4">{dayMenu.meals.breakfast?.join(", ") || "—"}</td>
                      <td className="p-4">{dayMenu.meals.lunch?.join(", ") || "—"}</td>
                      <td className="p-4">{dayMenu.meals.snacks?.join(", ") || "—"}</td>
                      <td className="p-4">{dayMenu.meals.dinner?.join(", ") || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500">No upcoming menu available</p>
        )}
      </div>
    </DashboardLayout>
  );
};

const MealCard = ({ title, value, icon }) => (
  <div className="bg-muted p-4 rounded-lg border">
    <div className="flex items-center gap-2 mb-2 text-primary">
      {icon}
      <span className="font-medium">{title}</span>
    </div>
    <p>{value?.length > 0 ? value.join(", ") : "Not Updated"}</p>
  </div>
);

export default MessMenu;