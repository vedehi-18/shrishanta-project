import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatusBadge } from '@/components/shared/StatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/context/AuthContext';
import { Plus, Clock } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

type Category = {
  id: number;
  category_name: string;
};

type Status = 'pending' | 'in-progress' | 'resolved';

type Complaint = {
  id: number;
  title: string;
  description: string;
  status: Status;
  priority: string;
  room_no: string;
  created_at: string;
  category_name?: string;
};

const Complaints = () => {
  const { user } = useAuth();

  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  const [formData, setFormData] = useState({
    category: '',
    title: '',
    description: '',
    priority: 'medium',
  });

  // ================= FETCH =================
  const fetchComplaints = async () => {
    if (!user?.email) return;
    try {
      const res = await fetch(
        `http://localhost:5000/complaints/student/${user.email}`
      );
      const data = await res.json();
      setComplaints(data);
    } catch {
      setComplaints([]);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch("http://localhost:5000/categories");
      const data = await res.json();
      setCategories(data);
    } catch {
      setCategories([]);
    }
  };

  useEffect(() => {
    fetchComplaints();
    fetchCategories();
  }, [user]);

  // ================= GROUP =================
  const groupedComplaints = complaints.reduce((acc: any, complaint) => {
    const date = new Date(complaint.created_at).toLocaleDateString();
    if (!acc[date]) acc[date] = [];
    acc[date].push(complaint);
    return acc;
  }, {});

  // ================= SUBMIT =================
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.category) {
      toast.error("Please select category");
      return;
    }

    try {
      const res = await fetch('http://localhost:5000/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user?.email, ...formData }),
      });

      const data = await res.json();

      if (data.success) {
        toast.success('Complaint submitted successfully');
        setIsOpen(false);
        setFormData({ category: '', title: '', description: '', priority: 'medium' });
        fetchComplaints();
      } else {
        toast.error(data.message || "Submission failed");
      }
    } catch {
      toast.error("Server error");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">My Complaints</h1>
            <p className="text-gray-500">Track and submit issues</p>
          </div>

          {user?.role === 'student' && (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="shadow-md">
                  <Plus className="mr-2 h-4 w-4" /> New Complaint
                </Button>
              </DialogTrigger>

              <DialogContent className="rounded-xl">
                <DialogHeader>
                  <DialogTitle>Submit Complaint</DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-3 mt-4">
                  <Select
                    value={formData.category}
                    onValueChange={(v) =>
                      setFormData({ ...formData, category: v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id.toString()}>
                          {cat.category_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Input
                    placeholder="Title"
                    required
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                  />

                  <Textarea
                    placeholder="Description"
                    required
                    value={formData.description}
                    onChange={e =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />

                  <Select
                    value={formData.priority}
                    onValueChange={(v) =>
                      setFormData({ ...formData, priority: v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button className="w-full">Submit</Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* LIST */}
        {Object.keys(groupedComplaints)
          .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
          .map((date) => (
            <div key={date} className="space-y-4">

              <h2 className="text-lg font-semibold border-b pb-1">
                📅 {date}
              </h2>

              {groupedComplaints[date].map((c: Complaint) => (
                <div
                  key={c.id}
                  className="p-5 rounded-xl bg-white/70 backdrop-blur-sm shadow-md border"
                >
                  <div className="flex justify-between">
                    <div>
                      <p className="font-semibold">{c.title}</p>
                      <p className="text-sm text-gray-500">
                        Room {c.room_no}
                      </p>
                    </div>
                    <StatusBadge status={c.status} />
                  </div>

                  <p className="text-sm mt-2 text-gray-700">
                    {c.description}
                  </p>

                  <div className="text-xs flex gap-1 mt-2 text-gray-500">
                    <Clock className="w-3 h-3" />
                    {new Date(c.created_at).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
        ))}

      </div>
    </DashboardLayout>
  );
};

export default Complaints;