import React, { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";
import { Trash2 } from "lucide-react";

interface Student {
  student_id: number;
  name: string;
  course: string;
  room_id?: number;
}

interface Room {
  room_id: number;
  room_no: number;
  capacity: number;
  students: Student[];
}

const AssignRoom = () => {
  const { user } = useAuth();

  const [roomNo, setRoomNo] = useState("");
  const [capacity, setCapacity] = useState(1);
  const [roomExists, setRoomExists] = useState(false);
  const [roomId, setRoomId] = useState<number | null>(null);

  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<number[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);

  const [selectedCourse, setSelectedCourse] = useState("");

  const fetchStudents = async () => {
    const res = await fetch(`http://localhost:5000/warden/students/${user.email}`);
    const data = await res.json();
    setStudents(data || []);
  };

  const fetchRooms = async () => {
    const res = await fetch(`http://localhost:5000/rooms/allocation/${user.email}`);
    const data = await res.json();

    const grouped: { [key: number]: Room } = {};

    data.forEach((item: any) => {
      if (!grouped[item.room_id]) {
        grouped[item.room_id] = {
          room_id: item.room_id,
          room_no: item.room_no,
          capacity: item.capacity,
          students: []
        };
      }

      if (item.student_id && item.name) {
        grouped[item.room_id].students.push({
          student_id: item.student_id,
          name: item.name,
          course: item.course_name || ""
        });
      }
    });

    setRooms(Object.values(grouped));
  };

  useEffect(() => {
    fetchStudents();
    fetchRooms();
  }, []);

  const checkRoom = async (roomNo: string) => {
    try {
      const res = await fetch(
        `http://localhost:5000/room-by-number/${roomNo}/${user.email}`
      );
      const data = await res.json();

      if (data && data.room_id) {
        setRoomId(data.room_id);
        setRoomExists(true);
      } else {
        setRoomId(null);
        setRoomExists(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (!roomNo || isNaN(Number(roomNo))) return;
    const timeout = setTimeout(() => checkRoom(roomNo), 300);
    return () => clearTimeout(timeout);
  }, [roomNo]);

  const handleCreateRoom = async () => {
    const res = await fetch("http://localhost:5000/get-or-create-room", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        room_no: parseInt(roomNo),
        capacity,
        email: user.email
      })
    });

    const data = await res.json();
    if (data.success) {
      setRoomId(data.room_id);
      setRoomExists(true);
      alert("Room created successfully ✅");
      fetchRooms();
    }
  };

  const handleAssign = async () => {
    if (!roomId) return alert("Please create/select a room first");
    if (selectedStudents.length === 0) return alert("Select students");

    const res = await fetch("http://localhost:5000/warden/assign-room", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        room_id: roomId,
        student_ids: selectedStudents
      })
    });

    const data = await res.json();
    if (data.success) {
      alert("Assigned successfully ✅");
      setSelectedStudents([]);
      fetchStudents();
      fetchRooms();
    } else {
      alert(data.message || "Assignment failed ❌");
    }
  };

  const handleDelete = async (student_id: number) => {
    const res = await fetch("http://localhost:5000/warden/remove-student-room", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ student_id })
    });

    const data = await res.json();
    if (data.success) {
      fetchStudents();
      fetchRooms();
    }
  };

  const courses = [...new Set(students.map(s => s.course))];

  const filteredStudents = selectedCourse
    ? students.filter(s => s.course === selectedCourse)
    : students;

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#F6F8FB]">
        <div className="mx-auto max-w-7xl px-6 py-8 md:px-8 md:py-10">
          <div className="space-y-8">
            <div className="rounded-[28px] border border-slate-200/80 bg-white/90 p-6 shadow-[0_10px_40px_rgba(15,23,42,0.05)] backdrop-blur">
              <h1 className="text-3xl font-bold tracking-tight text-slate-900 mb-0">
                Assign Room
              </h1>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-[380px_1fr]">
              <div className="rounded-[28px] border border-slate-200/80 bg-white p-6 shadow-[0_10px_40px_rgba(15,23,42,0.05)] xl:sticky xl:top-6 h-fit">
                <div className="space-y-4">
                  <Input
                    value={roomNo}
                    onChange={(e) => setRoomNo(e.target.value)}
                    placeholder="Room Number"
                    className="h-12 rounded-2xl border-slate-200 bg-slate-50 px-4 text-sm shadow-none focus-visible:ring-2 focus-visible:ring-[#6C8CF5]"
                  />

                  {!roomExists && (
                    <Input
                      type="number"
                      value={capacity}
                      onChange={(e) => setCapacity(Number(e.target.value))}
                      placeholder="Capacity"
                      className="h-12 rounded-2xl border-slate-200 bg-slate-50 px-4 text-sm shadow-none focus-visible:ring-2 focus-visible:ring-[#6C8CF5]"
                    />
                  )}

                  {!roomExists ? (
                    <Button
                      onClick={handleCreateRoom}
                      className="h-12 w-full rounded-2xl bg-gradient-to-r from-[#7A8CFF] to-[#5E72E4] text-white shadow-[0_10px_25px_rgba(94,114,228,0.28)] hover:opacity-95"
                    >
                      Create Room
                    </Button>
                  ) : (
                    <p className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-green-600 font-semibold">
                      ✅ Room already exists
                    </p>
                  )}

                  <select
                    value={selectedCourse}
                    onChange={(e) => {
                      setSelectedCourse(e.target.value);
                      setSelectedStudents([]);
                    }}
                    className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-700 outline-none transition focus:border-[#6C8CF5]"
                  >
                    <option value="">Select Course</option>
                    {courses.map((c, i) => (
                      <option key={i} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>

                  <select
                    multiple
                    value={selectedStudents.map(String)}
                    onChange={(e) =>
                      setSelectedStudents(
                        Array.from(e.target.selectedOptions).map((o) =>
                          Number(o.value)
                        )
                      )
                    }
                    className="min-h-[220px] w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700 outline-none transition focus:border-[#6C8CF5]"
                  >
                    {filteredStudents.length === 0 ? (
                      <option disabled>No students available</option>
                    ) : (
                      filteredStudents.map((s) => (
                        <option key={s.student_id} value={s.student_id}>
                          {s.name}
                        </option>
                      ))
                    )}
                  </select>

                  <Button
                    onClick={handleAssign}
                    className="h-12 w-full rounded-2xl bg-slate-900 text-white shadow-[0_10px_25px_rgba(15,23,42,0.18)] hover:bg-slate-800"
                  >
                    Assign
                  </Button>
                </div>
              </div>

              <div className="rounded-[28px] border border-slate-200/80 bg-white p-6 shadow-[0_10px_40px_rgba(15,23,42,0.05)]">
                <h2 className="text-xl font-semibold text-slate-900 mb-5">
                  Room Allocation
                </h2>

                {rooms.length === 0 ? (
                  <p className="text-gray-500">No data found</p>
                ) : (
                  <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white">
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[760px]">
                        <thead className="bg-slate-50">
                          <tr>
                            <th className="p-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                              Room No
                            </th>
                            <th className="p-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                              Capacity
                            </th>
                            <th className="p-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                              Students
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {rooms.map((room, index) => (
                            <tr
                              key={room.room_id}
                              className={`align-top border-t border-slate-200/80 ${
                                index % 2 === 0 ? "bg-white" : "bg-slate-50/40"
                              }`}
                            >
                              <td className="p-4">
                                <div className="inline-flex rounded-2xl bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-900">
                                  {room.room_no}
                                </div>
                              </td>

                              <td className="p-4">
                                <div className="inline-flex rounded-2xl bg-[#EEF2FF] px-3 py-2 text-sm font-semibold text-[#5E72E4]">
                                  {room.capacity}
                                </div>
                              </td>

                              <td className="p-4">
                                <div className="space-y-3">
                                  {room.students.map((s) => (
                                    <div
                                      key={s.student_id}
                                      className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200/70 bg-slate-50 px-4 py-3"
                                    >
                                      <span className="min-w-0 text-sm font-medium text-slate-800">
                                        {s.name}
                                        <span className="text-gray-500 text-sm ml-2">
                                          ({s.course})
                                        </span>
                                      </span>

                                      <button
                                        onClick={() => handleDelete(s.student_id)}
                                        className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-red-100 bg-red-50 text-red-500 transition hover:bg-red-100"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AssignRoom;
