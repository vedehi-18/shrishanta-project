import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { MoreVertical, Trash2 } from "lucide-react";

type Worker = {
  id: number;
  name: string;
  phone_no: string;
  category: number;
  category_name: string;
};

type Category = {
  id: number;
  category_name: string;
};

const WorkersDetail: React.FC = () => {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const [showAddModal, setShowAddModal] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    phone_no: "",
    category: "",
  });

  const [submitting, setSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const [openMenuId, setOpenMenuId] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  const [selectedCategory, setSelectedCategory] = useState<string>("");

  const fetchWorkers = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/workers");
      const data = await res.json();

      if (res.ok) {
        setWorkers(Array.isArray(data) ? data : []);
      } else {
        console.error("Workers API error:", data);
        alert(data.error || "Failed to fetch workers");
      }
    } catch (error) {
      console.error("Error fetching workers:", error);
      alert("Error fetching workers");
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/workers/categories");
      const data = await res.json();

      if (res.ok) {
        setCategories(Array.isArray(data) ? data : []);
      } else {
        console.error("Categories API error:", data);
        alert(data.error || "Failed to fetch categories");
      }
    } catch (error) {
      console.error("Error fetching categories:", error);
      alert("Error fetching categories");
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchWorkers(), fetchCategories()]);
      setLoading(false);
    };

    loadData();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpenMenuId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleCategoryFilterChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setSelectedCategory(e.target.value);
  };

  const handleAddWorker = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.phone_no || !formData.category) {
      alert("Please fill all fields");
      return;
    }

    try {
      setSubmitting(true);

      const res = await fetch("http://localhost:5000/api/workers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          phone_no: formData.phone_no.trim(),
          category: Number(formData.category),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || "Failed to add worker");
        return;
      }

      alert("Worker added successfully");

      setFormData({
        name: "",
        phone_no: "",
        category: "",
      });

      setShowAddModal(false);
      await fetchWorkers();
    } catch (error) {
      console.error("Error adding worker:", error);
      alert("Something went wrong while adding worker");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteWorker = async (workerId: number, workerName: string) => {
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${workerName}?`
    );

    if (!confirmDelete) return;

    try {
      setDeletingId(workerId);

      const res = await fetch(`http://localhost:5000/api/workers/${workerId}`, {
        method: "DELETE",
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || "Failed to delete worker");
        return;
      }

      alert("Worker deleted successfully");
      setOpenMenuId(null);
      await fetchWorkers();
    } catch (error) {
      console.error("Error deleting worker:", error);
      alert("Something went wrong while deleting worker");
    } finally {
      setDeletingId(null);
    }
  };

  const filteredWorkers =
    selectedCategory === ""
      ? workers
      : workers.filter((worker) => worker.category === Number(selectedCategory));

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#F6F8FB] font-grotesque">
        <main className="mx-auto max-w-7xl px-6 py-8 md:px-8 md:py-10">
          <div className="space-y-8">
            {/* Header */}
            <div className="rounded-[28px] border border-slate-200/80 bg-white p-6 shadow-[0_12px_40px_rgba(15,23,42,0.05)]">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <h2 className="text-3xl font-bold tracking-tight text-slate-900">
                    Workers Detail
                  </h2>
                  <p className="mt-1 text-slate-500">
                    View and manage maintenance workers.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="gradient"
                    size="lg"
                    onClick={() => setShowAddModal(true)}
                    className="rounded-2xl px-6 shadow-[0_10px_25px_rgba(58,43,143,0.22)]"
                  >
                    Add Worker
                  </Button>
                </div>
              </div>
            </div>

            {/* Filter */}
            <div className="rounded-[28px] border border-slate-200/80 bg-white p-5 shadow-[0_12px_40px_rgba(15,23,42,0.05)]">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <label className="text-sm font-medium text-slate-700">
                  Filter by Category:
                </label>

                <select
                  value={selectedCategory}
                  onChange={handleCategoryFilterChange}
                  className="h-11 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-700 outline-none transition focus:border-[#3A2B8F] sm:w-72"
                >
                  <option value="">All Categories</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.category_name}
                    </option>
                  ))}
                </select>

                {selectedCategory && (
                  <button
                    onClick={() => setSelectedCategory("")}
                    className="h-11 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                  >
                    Clear Filter
                  </button>
                )}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-hidden rounded-[28px] border border-slate-200/80 bg-white shadow-[0_12px_40px_rgba(15,23,42,0.05)]">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[880px] border-collapse text-left">
                  <thead className="bg-gradient-to-r from-[#3A2B8F] to-[#4A37A8] text-white">
                    <tr>
                      <th className="px-6 py-4 text-sm font-semibold">S.No.</th>
                      <th className="px-6 py-4 text-sm font-semibold">Worker Name</th>
                      <th className="px-6 py-4 text-sm font-semibold">Phone Number</th>
                      <th className="px-6 py-4 text-sm font-semibold">Work Type</th>
                      <th className="px-6 py-4 text-sm font-semibold text-center">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {loading ? (
                      <tr>
                        <td
                          colSpan={5}
                          className="py-10 text-center text-slate-500 font-medium"
                        >
                          Loading workers...
                        </td>
                      </tr>
                    ) : filteredWorkers.length > 0 ? (
                      filteredWorkers.map((worker, index) => (
                        <tr
                          key={worker.id}
                          className="border-b border-slate-200/80 transition hover:bg-slate-50/70"
                        >
                          <td className="px-6 py-4 text-slate-600">{index + 1}</td>

                          <td className="px-6 py-4">
                            <div className="font-semibold text-slate-900">
                              {worker.name}
                            </div>
                          </td>

                          <td className="px-6 py-4 text-slate-700">
                            {worker.phone_no}
                          </td>

                          <td className="px-6 py-4">
                            <span className="inline-flex rounded-full border border-blue-100 bg-blue-50 px-3 py-1 text-sm font-medium text-blue-700">
                              {worker.category_name || "Unknown"}
                            </span>
                          </td>

                          <td className="px-6 py-4 text-center">
                            <div
                              className="relative inline-block"
                              ref={openMenuId === worker.id ? menuRef : null}
                            >
                              <button
                                onClick={() =>
                                  setOpenMenuId(
                                    openMenuId === worker.id ? null : worker.id
                                  )
                                }
                                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:bg-slate-50 hover:text-slate-900"
                                title="More actions"
                              >
                                <MoreVertical className="h-4 w-4" />
                              </button>

                              {openMenuId === worker.id && (
                                <div className="absolute right-0 z-20 mt-2 w-44 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_14px_40px_rgba(15,23,42,0.12)]">
                                  <button
                                    onClick={() =>
                                      handleDeleteWorker(worker.id, worker.name)
                                    }
                                    disabled={deletingId === worker.id}
                                    className="flex w-full items-center gap-2 px-4 py-3 text-left text-sm font-medium text-red-600 transition hover:bg-red-50 disabled:opacity-60"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    {deletingId === worker.id
                                      ? "Deleting..."
                                      : "Delete"}
                                  </button>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan={5}
                          className="py-10 text-center text-slate-500 font-medium"
                        >
                          {selectedCategory
                            ? "No workers found for selected category."
                            : "No workers available."}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bottom Note */}
            <div className="rounded-[24px] border border-slate-200/80 bg-white px-5 py-4 shadow-[0_10px_30px_rgba(15,23,42,0.04)]">
              <p className="text-sm font-medium text-slate-900">
                Note:{" "}
                <span className="font-normal text-slate-600">
                  Workers are mapped with complaint categories like Electrical,
                  Plumbing, Furniture, WiFi, etc.
                </span>
              </p>
            </div>
          </div>

          {/* Add Worker Modal */}
          {showAddModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 backdrop-blur-[2px]">
              <div className="w-full max-w-lg rounded-[28px] border border-slate-200 bg-white p-7 shadow-[0_24px_80px_rgba(15,23,42,0.18)]">
                <h3 className="mb-2 text-2xl font-bold text-[#2E1A72]">
                  Add New Worker
                </h3>
                <p className="mb-6 text-slate-500">
                  Enter worker details below.
                </p>

                <form onSubmit={handleAddWorker} className="space-y-5">
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">
                      Worker Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter worker name"
                      className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm outline-none transition focus:border-[#3A2B8F] focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      name="phone_no"
                      value={formData.phone_no}
                      onChange={handleChange}
                      placeholder="Enter phone number"
                      className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm outline-none transition focus:border-[#3A2B8F] focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">
                      Work Type / Complaint Category
                    </label>
                    <select
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm outline-none transition focus:border-[#3A2B8F] focus:bg-white"
                    >
                      <option value="">Select Category</option>
                      {categories.map((category) => (
                        <option key={category.id} value={category.id}>
                          {category.category_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddModal(false)}
                      className="h-11 rounded-2xl border border-slate-200 bg-white px-5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                    >
                      Cancel
                    </button>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="h-11 rounded-2xl bg-gradient-to-r from-[#3A2B8F] to-[#2E1A72] px-5 text-sm font-medium text-white shadow-[0_10px_24px_rgba(58,43,143,0.24)] transition hover:opacity-95 disabled:opacity-60"
                    >
                      {submitting ? "Adding..." : "Add Worker"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </DashboardLayout>
  );
};

export default WorkersDetail;